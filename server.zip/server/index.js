const express = require("express");
const http = require("http");
const cors = require("cors");
const { Server } = require("socket.io");
const sessionRoutes = require("./routes/sessionRoutes");
const sequelize = require("./db"); // PostgreSQL connection

const app = express();
const server = http.createServer(app);

const io = new Server(server, {
  cors: {
    origin: "http://localhost:3000", // frontend URL
    methods: ["GET", "POST"]
  }
});

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use("/api/session", sessionRoutes); // FIXED plural to singular

// PostgreSQL DB sync
sequelize.sync().then(() => {
  console.log("🟢 PostgreSQL synced");
}).catch(err => {
  console.error("❌ PostgreSQL connection error:", err);
});

// Socket.IO logic
io.on("connection", (socket) => {
  console.log("🔌 New client connected:", socket.id);

  socket.on("send_message", (data) => {
    io.emit("receive_message", data); // broadcast to all
  });

  socket.on("disconnect", () => {
    console.log("❌ Client disconnected:", socket.id);
  });
});

const PORT = 5000;
server.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});
