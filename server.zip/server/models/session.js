// server/models/session.js
const { DataTypes } = require("sequelize");
const sequelize = require("../db");

const Session = sequelize.define("Session", {
  title: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  videoUrl: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  isLive: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
  },
  startedAt: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
  },
});

module.exports = Session;
