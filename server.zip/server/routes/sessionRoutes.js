const express = require("express");
const router = express.Router();
const Session = require("../models/session");

// Get latest session
router.get("/", async (req, res) => {
  try {
    const session = await Session.findOne({ order: [["startedAt", "DESC"]] });
    res.json(session);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch latest session" });
  }
});

// Start new live session
router.post("/start", async (req, res) => {
  const { title, videoUrl } = req.body;
  try {
    await Session.update({ isLive: false }, { where: { isLive: true } });
    const session = await Session.create({
      title,
      videoUrl,
      isLive: true,
    });
    res.json(session);
  } catch (err) {
    res.status(500).json({ error: "Failed to start session" });
  }
});

// Get currently live session
router.get("/live", async (req, res) => {
  try {
    const session = await Session.findOne({ where: { isLive: true } });
    res.json(session);
  } catch (err) {
    res.status(500).json({ error: "No live session" });
  }
});

// Stop all sessions
router.post("/stop", async (req, res) => {
  try {
    await Session.update({ isLive: false }, { where: {} });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: "Failed to stop sessions" });
  }
});

module.exports = router;
