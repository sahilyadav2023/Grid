const express = require("express");
const router = express.Router();

// Mock leaderboard data
const leaderboard = [
  { name: "Abhi", score: 120 },
  { name: "Jay", score: 100 },
  { name: "Sahil", score: 85 }
];

// GET /api/leaderboard
router.get("/", (req, res) => {
  res.json(leaderboard);
});

module.exports = router;
