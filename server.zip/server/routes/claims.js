const express = require("express");
const router = express.Router();

// Mock data for demo purposes
const fakeClaims = [
  { reward: "Notebook", status: "Approved", date: new Date() },
  { reward: "T-Shirt", status: "Pending", date: new Date(Date.now() - 86400000) },
  { reward: "Hoodie", status: "Rejected", date: new Date(Date.now() - 172800000) }
];

// GET /api/claims
router.get("/", (req, res) => {
  res.json(fakeClaims);
});

module.exports = router;
