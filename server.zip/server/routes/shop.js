const express = require("express");
const router = express.Router();
const ShopItem = require("../models/ShopItem");

// Fetch all shop items
router.get("/", async (req, res) => {
  try {
    // TODO: Replace with real user ID from Firebase Auth if available
    const userId = req.user ? req.user.uid : "guest";
    const shopItems = await ShopItem.find();
    console.log(`User ${userId} fetched shop items:`, shopItems);
    res.json(shopItems);
  } catch (error) {
    console.error("Error fetching shop items:", error);
    res.status(500).json({ error: "Failed to fetch shop items" });
  }
});

module.exports = router;
