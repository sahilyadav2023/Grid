const express = require("express");
const http = require("http");
const cors = require("cors");
const { Server } = require("socket.io");
const sequelize = require("./db");

const sessionRoutes = require("./routes/sessionRoutes");
const shopRoutes = require("./routes/shop");
const leaderboardRoutes = require("./routes/leaderboard");
const claimsRoutes = require("./routes/claims");

const app = express();
const server = http.createServer(app);

// Sync database
sequelize.sync().then(() => {
  console.log("🟢 PostgreSQL synced");
}).catch((err) => {
  console.error("❌ DB sync error:", err);
});

// Middleware
app.use(cors());
app.use(express.json());

// API Routes
app.use("/api/session", sessionRoutes);
app.use("/api/shop", shopRoutes);
app.use("/api/leaderboard", leaderboardRoutes);
app.use("/api/claims", claimsRoutes); // ⚠️ check this file ends with: module.exports = router;

// Socket.IO Setup
const io = new Server(server, {
  cors: {
    origin: "http://localhost:3000",
    methods: ["GET", "POST"]
  }
});

io.on("connection", (socket) => {
  console.log("🔌 New client connected:", socket.id);

  socket.on("send_message", (data) => {
    io.emit("receive_message", data);
  });

  socket.on("disconnect", () => {
    console.log("❌ Client disconnected:", socket.id);
  });
});

// Start Server
const PORT = 5000;
server.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
