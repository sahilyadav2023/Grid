let currentVideoURL = 'https://www.youtube.com/embed/default_live_url'; // default

export const getLiveVideoURL = (req, res) => {
  res.json({ videoURL: currentVideoURL });
};

export const setLiveVideoURL = (req, res) => {
  const { videoURL } = req.body;
  currentVideoURL = videoURL;
  res.json({ success: true, videoURL });
};
